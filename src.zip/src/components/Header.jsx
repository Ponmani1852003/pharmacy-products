// function Header() {
//   return (
//     <header className="bg-white text-black p-4">
//       Header
//     </header>
//   );
// }

// export default Header;